package com.stg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HouseRentalManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}

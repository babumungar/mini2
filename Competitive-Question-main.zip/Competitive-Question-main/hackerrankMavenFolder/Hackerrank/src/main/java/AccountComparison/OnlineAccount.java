package AccountComparison;

public interface OnlineAccount {
	public static final int BASEPRICE = 10;
	public static final int REGULARMOVIEPRICE = 50;
	public static final int EXCLUSIVEMOVIEPRICE = 80;

}
